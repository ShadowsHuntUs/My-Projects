﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at https://go.microsoft.com/fwlink/?LinkId=234238

namespace PROG1442_04_Elliot_Brown_Ford
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class RockPaperScissor : Page
    {
        public RockPaperScissor()
        {
            this.InitializeComponent();
        }

        private void btnBack_Click(object sender, RoutedEventArgs e)
        {
            this.Frame.Navigate(typeof(MainPage));
        }

        //private bool buttonWasClicked = false;

        private void button_Click(object sender, RoutedEventArgs e)
        {
            //buttonWasClicked = true;          
            Random compSelected = new Random();
            for (int i = 0; i < 3; i++)
            {
                comboBox1.SelectedIndex = compSelected.Next(0, 3);
            }
            //if(buttonWasClicked == true)
            //{
            //    stpnlForYou.Visibility = Visibility.Collapsed;
            //    stpnlForComp.Visibility = Visibility.Collapsed;
            //}
            if (comboBox.SelectedIndex == 0 && comboBox1.SelectedIndex == 2)
            {
                textBlock3.Text = "You Won.Great Job";
                textBlock4.Text = "";

            } else if (comboBox.SelectedIndex == 1 && comboBox1.SelectedIndex == 0)
            {
                textBlock3.Text = "You Won.Great Job";
                textBlock4.Text = "";
            }
            else if (comboBox.SelectedIndex == 2 && comboBox1.SelectedIndex == 1)
            {

                textBlock3.Text = "You Won.Great Job";
                textBlock4.Text = "";
            }
            else if (comboBox.SelectedIndex == 3 && comboBox1.SelectedIndex == 0)
            {
                textBlock4.Text = "You Comp.Great Job Comp";
                textBlock3.Text = "You Lost.Better Luck Next time";
                textBlock5.Text = "";
            }
            else if (comboBox.SelectedIndex == 0 && comboBox1.SelectedIndex == 1)
            {
                textBlock4.Text = "You Comp.Great Job Comp";
                textBlock3.Text = "You Lost.Better Luck Next time";
                textBlock5.Text = "";

            }
            else if (comboBox.SelectedIndex == 1 && comboBox1.SelectedIndex == 2)
            {
                textBlock4.Text = "You Comp.Great Job Comp";
                textBlock3.Text = "You Lost.Better Luck Next time";
                textBlock5.Text = "";

            }
            else if (comboBox.SelectedIndex == comboBox1.SelectedIndex)
            {
                textBlock4.Text = "";
                textBlock3.Text = "";
                textBlock5.Text = "Its a Tie. What are the odds of that! Try again";
            }
            else if (comboBox.SelectedValue == null)
            {
                
                textBlock4.Text = "";
                textBlock3.Text = "";
                textBlock5.Text = "Please make a chose";
                comboBox1.SelectedValue = null;
            }
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            comboBox.SelectedValue = null;
            comboBox1.SelectedValue = null;
            textBlock3.Text = "";
            textBlock4.Text = "";
            textBlock5.Text = "";
        }
    }
}
